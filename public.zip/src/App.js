
import './App.css';

function App() {
  return (
    <div className="App">
      <h1>Hello Dojo!</h1>
      <h3>Things i need to do:</h3>
        <li>Learn react</li>
        <li>Climb Mt Everest</li>
        <li>Run a marathon</li>
        <li>Feed the dogs</li>
    </div>
  );
}

export default App;
